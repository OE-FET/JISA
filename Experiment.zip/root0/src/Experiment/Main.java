package Experiment;

import JISA.Addresses.*;
import JISA.Control.*;
import JISA.Devices.*;
import JISA.Experiment.*;
import JISA.GUI.*;
import JISA.Util;
import JISA.VISA.*;

/**
 * JISA Template Application.
 *
 * Write the code you want to run when the application is run in the "run(...)" method.
 *
 * If you are not going to use any GUI elements, remove "extends GUI" from the line below.
 */
public class Main extends GUI {

    public static void run(String[] args) throws Exception {

        // TODO: Replace this with your code
        GUI.error("No Code", "No Code!", "You haven't written any code!");

    }


    public static void main(String[] args) {

        try {
            run(args);
        } catch (Exception e) {
            Util.exceptionHandler(e);
        }

    }
}
